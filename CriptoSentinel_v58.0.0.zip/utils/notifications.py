class Notifier:
    """Envio de notificações genéricas (email, webhook, etc.)."""

    def notify(self, channel, message):
        # TODO: implementar notificações via diferentes canais
        pass
