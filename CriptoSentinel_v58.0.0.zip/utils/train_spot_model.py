def train_spot_model(data):
    """Pipeline legado de treinamento para spot."""
    # TODO: implementar treinamento spot
    pass
