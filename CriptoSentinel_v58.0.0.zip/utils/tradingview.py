class TradingViewClient:
    """Integração com TradingView para sinais e alertas."""

    def get_signals(self, symbol):
        # TODO: implementar integração
        return []
