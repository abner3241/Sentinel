def analyze_context(data):
    """Analisa e extrai insights de dados de contexto."""
    # TODO: implementar análise de contexto
    return {}
