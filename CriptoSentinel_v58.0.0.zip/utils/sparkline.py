def sparkline(data):
    """Gera sparkline ASCII de uma série de valores."""
    # TODO: implementar geração de sparkline
    return ''
