def collect_context(source):
    """Coleta dados de contexto a partir de diferentes fontes."""
    # TODO: implementar coleta de contexto
    return []
