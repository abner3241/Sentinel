class PerformanceStore:
    """Armazena métricas de performance em base persistente."""

    def save(self, metrics):
        # TODO: implementar persistência de métricas
        pass
