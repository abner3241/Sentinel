def place_bracket_order(client, symbol, qty, entry, stop, take_profit):
    """Coloca ordem bracket (entry, stop loss e take profit)."""
    # TODO: implementar bracket orders
    pass
