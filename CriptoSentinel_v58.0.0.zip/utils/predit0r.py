class Predit0r:
    """Pipeline legado de predição alternativa."""

    def predict(self, data):
        # TODO: implementar predição
        return 0.0
