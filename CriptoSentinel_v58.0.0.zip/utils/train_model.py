def train_model(data):
    """Pipeline legado de treinamento de modelo."""
    # TODO: implementar treinamento
    pass
