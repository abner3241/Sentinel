# Stub for legacy module exportador_sinais.py
