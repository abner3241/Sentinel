# Stub for legacy module arbitrage.py
