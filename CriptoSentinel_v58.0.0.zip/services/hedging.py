# Stub for legacy module hedging.py
