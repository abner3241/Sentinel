# Stub for legacy module signals_chain.py
