from backtest.run_backtest import main

def main():
    # Simple entrypoint for backtesting
    main()

if __name__ == "__main__":
    main()
