# Generated gRPC stub: sentinel_pb2_grpc
